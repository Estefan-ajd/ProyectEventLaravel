/*SCRIPT CARRITO*/

window.onload = function () {
	
	/**
	* Varia el localStorage
	*/
	function vaciarlocalStorage() {
		localStorage.clear();
	}

	vaciarlocalStorage();
}